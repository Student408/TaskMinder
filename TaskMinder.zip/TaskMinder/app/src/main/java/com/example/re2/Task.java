package com.example.re2;

import java.util.Date;

public class Task {
    private final String name;
    private final Date dateTime;
    private int notificationId;

    public Task(String name, Date dateTime) {
        this.name = name;
        this.dateTime = dateTime;
    }

    public String getName() {
        return name;
    }

    public Date getDateTime() {
        return dateTime;
    }

    public int getNotificationId() {
        return notificationId;
    }

    public void setNotificationId(int notificationId) {
        this.notificationId = notificationId;
    }

    // Get the task name (description)
    public String getDescription() {
        return name;
    }
}
