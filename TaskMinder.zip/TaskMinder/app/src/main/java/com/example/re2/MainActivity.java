package com.example.re2;

import android.Manifest;
import android.app.AlarmManager;
import android.app.DatePickerDialog;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.TimePickerDialog;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.TimePicker;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class MainActivity extends AppCompatActivity {
    private static final String CHANNEL_ID = "task_reminder_channel";
    private static final String PREFS_NAME = "TaskPrefs";
    private static final String TASK_LIST_KEY = "taskList";
    private final Calendar selectedDateTime = Calendar.getInstance();
    private EditText taskInput;
    private List<Task> tasks;
    private TaskAdapter taskAdapter;
    private int notificationId = 1;
    private SharedPreferences taskPrefs;
    private BroadcastReceiver notificationRemoveReceiver;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        taskInput = findViewById(R.id.taskInput);
        Button remindButton = findViewById(R.id.remindButton);
        ListView taskListView = findViewById(R.id.taskListView);

        tasks = new ArrayList<>();
        taskAdapter = new TaskAdapter(this, R.layout.task_list_item, tasks);
        taskListView.setAdapter(taskAdapter);

        taskPrefs = getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);

        createNotificationChannel();
        registerNotificationRemoveReceiver();

        remindButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String taskName = taskInput.getText().toString().trim();
                if (!taskName.isEmpty()) {
                    boolean isTaskNameExists = checkTaskNameExists(taskName);
                    if (!isTaskNameExists) {
                        showDatePicker();
                    } else {
                        Toast.makeText(MainActivity.this, "Task name already exists.", Toast.LENGTH_SHORT).show();
                    }
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a task name.", Toast.LENGTH_SHORT).show();
                }
            }
        });

        taskListView.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                Task task = tasks.get(position);
                deleteTask(task, position);
                return true;
            }
        });

        loadSavedTasks();
    }

    private boolean checkTaskNameExists(String taskName) {
        for (Task task : tasks) {
            if (task.getName().equalsIgnoreCase(taskName)) {
                return true;
            }
        }
        return false;
    }

    private void createNotificationChannel() {
        CharSequence name = "Task Reminder Channel";
        String description = "Channel for Task Reminder";
        int importance = NotificationManager.IMPORTANCE_HIGH;
        NotificationChannel channel = new NotificationChannel(CHANNEL_ID, name, importance);
        channel.setDescription(description);

        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        if (notificationManager != null) {
            notificationManager.createNotificationChannel(channel);
        }
    }

    private void showDatePicker() {
        final Calendar currentDate = Calendar.getInstance();
        int year = currentDate.get(Calendar.YEAR);
        int month = currentDate.get(Calendar.MONTH);
        int day = currentDate.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(MainActivity.this, new DatePickerDialog.OnDateSetListener() {
            @Override
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                selectedDateTime.set(Calendar.YEAR, year);
                selectedDateTime.set(Calendar.MONTH, monthOfYear);
                selectedDateTime.set(Calendar.DAY_OF_MONTH, dayOfMonth);

                showTimePicker();
            }
        }, year, month, day);

        datePickerDialog.show();
    }

    private void showTimePicker() {
        int selectedHour = selectedDateTime.get(Calendar.HOUR_OF_DAY);
        int selectedMinute = selectedDateTime.get(Calendar.MINUTE);

        TimePickerDialog timePickerDialog = new TimePickerDialog(MainActivity.this, new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker view, int hourOfDay, int minute) {
                selectedDateTime.set(Calendar.HOUR_OF_DAY, hourOfDay);
                selectedDateTime.set(Calendar.MINUTE, minute);
                selectedDateTime.set(Calendar.SECOND, 0); // Set seconds to 0

                String taskName = taskInput.getText().toString().trim();
                if (!taskName.isEmpty()) {
                    Task newTask = new Task(taskName, selectedDateTime.getTime());
                    newTask.setNotificationId(notificationId); // Set the unique notificationId for each task
                    tasks.add(newTask);
                    saveTasksToSharedPreferences(); // Save the tasks to SharedPreferences
                    taskAdapter.notifyDataSetChanged();
                    scheduleNotification(newTask); // Pass the Task object only (no need to pass notificationId again)
                    notificationId++;
                } else {
                    Toast.makeText(MainActivity.this, "Please enter a task name.", Toast.LENGTH_SHORT).show();
                }
            }
        }, selectedHour, selectedMinute, false);

        timePickerDialog.show();
    }

    private void scheduleNotification(Task task) {
        Intent intent = new Intent(this, NotificationReceiver.class);
        intent.putExtra("task", task.getName());
        intent.putExtra("notificationId", task.getNotificationId()); // Pass the notificationId to the NotificationReceiver

        PendingIntent pendingIntent;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            pendingIntent = PendingIntent.getBroadcast(
                    this,
                    task.getNotificationId(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
            );
        } else {
            // For devices below Android 12, use the FLAG_UPDATE_CURRENT flag without FLAG_IMMUTABLE
            pendingIntent = PendingIntent.getBroadcast(
                    this,
                    task.getNotificationId(),
                    intent,
                    PendingIntent.FLAG_UPDATE_CURRENT
            );
        }

        AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
        if (alarmManager != null) {
            alarmManager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, task.getDateTime().getTime(), pendingIntent);
        }

        Toast.makeText(this, "Task scheduled successfully.", Toast.LENGTH_SHORT).show();
    }

    private void deleteTask(Task task, int position) {
        tasks.remove(position);
        cancelNotification(task.getNotificationId());
        taskAdapter.notifyDataSetChanged();
        saveTasksToSharedPreferences(); // Save the updated tasks list to SharedPreferences
    }

    private void cancelNotification(int notificationId) {
        Intent intent = new Intent(this, NotificationReceiver.class);
        PendingIntent pendingIntent = PendingIntent.getBroadcast(
                this,
                notificationId,
                intent,
                PendingIntent.FLAG_NO_CREATE | PendingIntent.FLAG_IMMUTABLE
        );

        if (pendingIntent != null) {
            AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
            if (alarmManager != null) {
                alarmManager.cancel(pendingIntent);
                pendingIntent.cancel();
            }
        }
    }

    private void saveTasksToSharedPreferences() {
        SharedPreferences.Editor editor = taskPrefs.edit();
        Gson gson = new Gson();
        String jsonTasks = gson.toJson(tasks);
        editor.putString(TASK_LIST_KEY, jsonTasks);
        editor.apply();
    }

    private void loadSavedTasks() {
        Gson gson = new Gson();
        String jsonTasks = taskPrefs.getString(TASK_LIST_KEY, "");
        Type type = new TypeToken<List<Task>>() {
        }.getType();
        List<Task> savedTasks = gson.fromJson(jsonTasks, type);

        if (savedTasks != null) {
            tasks.addAll(savedTasks);

            // Sort the tasks list based on date and time
            Collections.sort(tasks, new TaskComparator());

            // Update the notificationId for each task based on the new order
            updateNotificationIds();

            taskAdapter.notifyDataSetChanged();
        }
    }

    private void updateNotificationIds() {
        for (int i = 0; i < tasks.size(); i++) {
            tasks.get(i).setNotificationId(i + 1);
        }
    }

    // Custom comparator for sorting tasks based on date and time
    private static class TaskComparator implements Comparator<Task> {
        @Override
        public int compare(Task task1, Task task2) {
            return task1.getDateTime().compareTo(task2.getDateTime());
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        // Unregister the BroadcastReceiver when the activity is destroyed
        unregisterReceiver(notificationRemoveReceiver);
    }

    private void registerNotificationRemoveReceiver() {
        // Create a BroadcastReceiver to handle notification removal events
        notificationRemoveReceiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                // Get the notificationId of the removed notification
                int removedNotificationId = intent.getIntExtra("notificationId", -1);
                if (removedNotificationId != -1) {
                    // Find the corresponding task with the given notificationId
                    Task removedTask = null;
                    for (Task task : tasks) {
                        if (task.getNotificationId() == removedNotificationId) {
                            removedTask = task;
                            break;
                        }
                    }

                    // Remove the task from the list and cancel the notification
                    if (removedTask != null) {
                        tasks.remove(removedTask);
                        cancelNotification(removedNotificationId);
                        saveTasksToSharedPreferences(); // Save the updated tasks list to SharedPreferences
                        taskAdapter.notifyDataSetChanged();
                        Toast.makeText(MainActivity.this, "Task removed from the list.", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        };

        // Register the BroadcastReceiver with the intent filter for notification removal events
        IntentFilter notificationRemoveIntentFilter = new IntentFilter();
        notificationRemoveIntentFilter.addAction(NotificationReceiver.NOTIFICATION_REMOVED_ACTION);
        registerReceiver(notificationRemoveReceiver, notificationRemoveIntentFilter);
    }
}
