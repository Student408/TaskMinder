package com.example.re2;

import android.Manifest;
import android.app.Notification;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.RingtoneManager;
import android.net.Uri;
import android.widget.Toast;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;
import androidx.core.content.ContextCompat;

public class NotificationReceiver extends BroadcastReceiver {
    private static final String CHANNEL_ID = "task_reminder_channel";
    private static final String ACTION_REMOVE_TASK = "com.example.re2.ACTION_REMOVE_TASK";
    public static final String NOTIFICATION_REMOVED_ACTION = "com.example.re2.NOTIFICATION_REMOVED_ACTION";

    @Override
    public void onReceive(Context context, Intent intent) {
        String task = intent.getStringExtra("task");
        int notificationId = intent.getIntExtra("notificationId", 0);

        // Create a sound URI
        Uri soundUri = RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION);

        // Create the remove task intent
        Intent removeTaskIntent = new Intent(context, NotificationReceiver.class);
        removeTaskIntent.setAction(ACTION_REMOVE_TASK);
        removeTaskIntent.putExtra("notificationId", notificationId); // Pass the notificationId to the intent
        PendingIntent removeTaskPendingIntent = PendingIntent.getBroadcast(context, notificationId, removeTaskIntent, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);

        // Build the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_notification)
                .setContentTitle("Task Reminder")
                .setContentText(task)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setSound(soundUri)
                .setAutoCancel(false)
                .addAction(R.drawable.ic_remove, "Remove Task", removeTaskPendingIntent);

        Notification notification = builder.build();
        notification.flags |= Notification.FLAG_NO_CLEAR; // Make the notification sticky

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(context);

        // Check if the permission is granted
        if (ContextCompat.checkSelfPermission(context, Manifest.permission.VIBRATE) == PackageManager.PERMISSION_GRANTED) {
            notificationManager.notify(notificationId, notification);
        } else {
            // Handle the case where the permission is not granted
            // You can display a toast message or request the permission here
            Toast.makeText(context, "Vibrate Permission required", Toast.LENGTH_SHORT).show();
        }

        // Handle the remove task action
        if (intent.getAction() != null && intent.getAction().equals(ACTION_REMOVE_TASK)) {
            int removedNotificationId = intent.getIntExtra("notificationId", 0);
            notificationManager.cancel(removedNotificationId); // Remove the notification

            // Send a broadcast to notify MainActivity that the task notification was removed
            Intent removedIntent = new Intent(NOTIFICATION_REMOVED_ACTION);
            removedIntent.putExtra("notificationId", removedNotificationId);
            context.sendBroadcast(removedIntent);
        }
    }
}
