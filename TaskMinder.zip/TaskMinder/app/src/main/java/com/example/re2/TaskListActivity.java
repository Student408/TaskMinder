package com.example.re2;

import android.os.Bundle;
import android.os.Parcelable;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.ArrayList;

public class TaskListActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_task_list);

        // Get the list of Parcelable tasks passed from MainActivity
        ArrayList<Parcelable> parcelableTasks = getIntent().getParcelableArrayListExtra("tasks");

        // Convert Parcelable tasks back to Task objects
        ArrayList<Task> tasksList = new ArrayList<>();
        for (Parcelable parcelable : parcelableTasks) {
            if (parcelable instanceof Task) {
                Task task = (Task) parcelable;
                tasksList.add(task);
            }
        }

        // Create an ArrayList of task descriptions to display in the ListView
        ArrayList<String> taskDescriptions = new ArrayList<>();
        for (Task task : tasksList) {
            String description = task.getDescription();
            taskDescriptions.add(description);
        }

        // Display the tasks in a ListView
        ListView listView = findViewById(R.id.taskListView);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, taskDescriptions);
        listView.setAdapter(adapter);
    }
}
