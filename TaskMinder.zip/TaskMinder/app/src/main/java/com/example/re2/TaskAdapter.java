package com.example.re2;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.TextView;

import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

public class TaskAdapter extends ArrayAdapter<Task> {
    private final Context context;
    private final List<Task> tasks;

    public TaskAdapter(Context context, int resource, List<Task> tasks) {
        super(context, resource, tasks);
        this.context = context;
        this.tasks = tasks;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View view = convertView;
        if (view == null) {
            LayoutInflater inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            view = inflater.inflate(R.layout.task_list_item, null);
        }

        Task task = tasks.get(position);
        if (task != null) {
            TextView taskNameTextView = view.findViewById(R.id.taskNameTextView);
            TextView dateTimeTextView = view.findViewById(R.id.dateTimeTextView);

            taskNameTextView.setText(task.getName());

            SimpleDateFormat sdf = new SimpleDateFormat("MMM d, yyyy hh:mm a", Locale.getDefault());
            dateTimeTextView.setText(sdf.format(task.getDateTime()));
        }

        return view;
    }
}
